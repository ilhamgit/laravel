<div class="py-5 bg-green" id="box4">
  <div class="container mt-3" id="nft">
  <h1 class="texttitle py-4 text-center" data-entrance="fade">Our NFT</h1>
  <center data-entrance="from-left">
    <button class="tablink" onclick="openPage('skin', this, 'red')" id="defaultOpen">Skin Color</button>
    <button class="tablink" onclick="openPage('texture', this, 'green')">Skin Texture</button>
    <button class="tablink" onclick="openPage('scalp', this, 'blue')">Scalp Lines</button>
    <button class="tablink" onclick="openPage('leg', this, 'orange')">Horse Leg Pattern</button>
    <button class="tablink" onclick="openPage('hair', this, 'orange')">Hair Shape</button>
    <button class="tablink" onclick="openPage('tail', this, 'orange')">Tail Shape</button>
</center>

    <div id="skin" class="tabcontent mt-3" data-entrance="from-left">
        <center>
      <h1>Horse Skin Color</h1>
       <br>
      <div class="container">
        <div class="row">
          <div class="col-sm">
            <img width="394" height="295" src="{{ asset('assets/newhome/storage/img/brown-horse.jpeg') }}" style="border-radius:15px;">
            <h3 class="skin-heading-title">Brown Horse</h3>
        </div>
          <div class="col-sm">
            <img width="394" height="295" src="{{ asset('assets/newhome/storage/img/white-horse.jpeg') }}" style="border-radius:15px;">
            <h3 class="skin-heading-title">White Horse</h3>
          </div>
        
        </div>
      </div>
     
    </div>

    <div id="texture" class="tabcontent mt-3">
    
      Skin Texture (coming soon)
    </div>

    <div id="scalp" class="tabcontent mt-3">
       Scalp Lines (coming soon)
    </div>

    <div id="leg" class="tabcontent mt-3">
      Horse Leg Pattern (coming soon)
    </div>

    <div id="hair" class="tabcontent mt-3">
      Hair Shape (coming soon)
    </div>

    <div id="tail" class="tabcontent mt-3">
    Tail Shape (coming soon)
    </div>
    <p style="text-align:center;padding-top:10px;" data-entrance="from-bottom"><b>For more details, You can refer to the</b> <a target="_blank" style="color:#E0CD9A;text-decoration:none;" href="https://meta-horse.io/wp-content/uploads/sites/72/2022/03/Metahorse-Whitepaper-EN_1-1.pdf">Whitepaper</a>.</p>
    </center>
    <script>
    function openPage(pageName,elmnt,color) {
      var i, tabcontent, tablinks;
      tabcontent = document.getElementsByClassName("tabcontent");
      for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
      }
      tablinks = document.getElementsByClassName("tablink");
      for (i = 0; i < tablinks.length; i++) {
        // tablinks[i].style.backgroundColor = "";
        tablinks[i].classList.remove("activeTab");
      }
      document.getElementById(pageName).style.display = "block";
      // elmnt.style.backgroundColor = color;
      elmnt.classList.add("activeTab");
    }

    // Get the element with id="defaultOpen" and click on it
    document.getElementById("defaultOpen").click();
    </script>
  </div>
</div>
