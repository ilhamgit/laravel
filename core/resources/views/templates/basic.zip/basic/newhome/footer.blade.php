
<div class="overlay bg-green">
  <section class="bg-stadium">
        <div class="container">

          <div class="row">
            <div class="col-md-6 py-5 px-3 d-flex align-middle align-center" data-entrance="from-left">
              <img src="{{ asset('assets/newhome/storage/img/horse-jockey.png')}}" class="w-100 m-auto">
            </div>

            <div class="col-md-6 py-5 px-3 d-flex align-middle align-center" data-entrance="from-right">
              <form class="newsletter-form m-auto">
                <h2 class="w-100" style="font-weight: 700; font-size: 40px;">Join MetaHorse Community!</h2>
                  <div class="form-group">
                      <div class="row">
                        <div class="col-md-10">
                          <input type="email" id="subscriber" class="form-control d-inline-block my-2" placeholder="@lang('Your Email Address')" name="email" required>
                        </div>
                        <div class="col-md-2">
                          <button type="button" class="btn btn-default d-inline-block my-2">@lang('Send')</button>
                        </div>
                      </div>
                  </div>
              </form>
            </div>
          </div>
        </div>
  </section>
</div>

<div class="py-5" id="full">
    <div class="container py-4 ">
        <img src="{{ asset('assets/newhome//storage/img/logo.png') }}" width="130px">
    </div>
    <div class="container py-4">

        <!--socket test starts-->
         <button id="connect" class="btn btn-default">connect</button>
         <button id="new_category_btn2" class="btn btn-default">click</button>
          <div class="container">
              <p>Watch here</p>
              <div id="team1_score"></div>
           </div>
         <!--socket test ends-->
                         
        <p id="text"><a href="/" class="link text-white me-2">Terms of Service</a> | <a href="/" class="link text-white ms-2"> Privacy Policy</a></p>
    </div>
</div>

<script>
        'use strict';

        (function ($) {
            $('.subs').on('click',function () {
                var email = $('#subscriber').val();
                var csrf = '{{csrf_token()}}'
                var url = "{{ route('subscriber.store') }}";
                var data = {email:email, _token:csrf};

                $.post(url, data,function(response){
                    if(response.success){
                        notify('success', response.success);
                        $('#subscriber').val('');
                    }else{
                        notify('error', response.error);
                    }
                });

            });
        })(jQuery);
    </script>