<div class="background-overlay bg-green" id="tokenomic">

	<div class="container">
		<h1 class="texttitle py-4 text-center" data-entrance="fade">Tokenomics</h1>
	    <div class="row">
	        <div class="col-md-6 d-flex align-middle align-center p-3" data-entrance="from-left">
	        	<img src="{{ asset('assets/newhome//storage/img/tokenomic-chart.png') }}" class="m-auto w-75">
	        </div>
	        <div class="col-md-6 d-flex align-middle align-center p-3" data-entrance="from-right">
	            <img src="{{ asset('assets/newhome//storage/img/tokenomic-table.png') }}" class="m-auto w-100">
	        </div>
	    </div>
	</div>

</div>