<center>
    <div class="bg-green" id="whitepaper">

        <div class="container">
            <div class="row py-5">
                <div class="col-sm-4 fadeInDown" data-entrance="from-top">
                    <img src="{{ asset('assets/newhome//storage/img/horse-flag-1-green.png') }}">
                    <h3 class="title pt-3">Own a racehorse</h3>
                </div>

                <div class="col-sm-4 fadeInDown" data-entrance="from-top">
                    <img src="{{ asset('assets/newhome//storage/img/horse-flag-2-green.png') }}">
                    <h3 class="title pt-3">Hold Metahorse coin</h3>
                </div>

                <div class="col-sm-4 fadeInDown" data-entrance="from-top">
                    <img src="{{ asset('assets/newhome//storage/img/horse-flag-3-green.png') }}">
                    <h3 class="title pt-3">Race</h3>
                </div>
            </div>
        </div>

</div>
</center>