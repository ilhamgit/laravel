<center>
    <section class="bg-green" id="video">
    	<div class="container">

	    	<div class="row">
	    		<div class="col-md-12 py-5 px-3">
	      
				    <video controls class="mx-auto d-block my-4 w-100" data-entrance="from-top">
				        <source src="https://meta-horse.io/wp-content/uploads/Metahorse.mp4" type="video/mp4">
				             
				      </video>

			      	<button type="button" class="btn btn-default btn-lg" data-entrance="from-bottom">Whitepaper</button>
			      </div>
	    	</div>
     	</div>
    </section>
</center>
