<link rel="stylesheet" type="text/css" href="//netdna.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css">
<link rel='stylesheet' id='font-awesome-css'  href='https://meta-horse.io/wp-content/plugins/menu-icons/css/fontawesome/css/all.min.css?ver=4.7.0' media='all' />

<div class="container bootstrap snippets bootdey" id="roadmap">
    <section id="news" class="white-bg padding-top-bottom desktop-timeline">
        <div class="container bootstrap snippets bootdey">
        <h1 class="texttitle py-4 text-center" style="margin: 40px 0;" data-entrance="from-top">Roadmap</h1>
            <div class="timeline" data-entrance="from-bottom">
               
                <div class="row">
                    <div class="col-sm-6 news-item left item-1">
                        <div class="news-content">
                            
                            <div class="news-media">
                               
                            </div>
                            
                            <ul>
                                <li>NFT design</li>
                                <li><span style="font-weight: 400;">Officia2l website emerge</span></li>
                                <li><span style="font-weight: 400;">Seed round private placement</span></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-sm-6 news-item">
                    <span class="timeline-text-left">Mar 2022</span>
                    </div>
                    </div>
                    <div class="row">
                    <div class="col-sm-6 news-item">
                    <span class="timeline-text-right">Apr 2022</span>
                    </div>
                    <div class="col-sm-6 news-item right item-2">
                        <div class="news-content">
                            
                            <div class="news-media gallery">
                                <a class="colorbox cboxElement" href="#">
                                </a>
                                <a class="colorbox cboxElement" href="#"></a>
                            </div>
                            <ul>
                                <li><span style="font-weight: 400;">Publish horse NFT design</span></li>
                                <li><span style="font-weight: 400;">Private sale</span></li>
                                <li><span style="font-weight: 400;">Public sale</span></li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-sm-6 news-item left item-3">
                        <div class="news-content">
                            <div class="news-media video">
                                <a class="colorbox-video cboxElement" href="#">
                                </a>
                            </div>
                            <ul>
                                <li><p><span style="font-weight: 400;">Governance token launch</span></p></li>
                                <li><p><span style="font-weight: 400;">NFT blind box and training centre NFT put on sale</span></p></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-sm-6 news-item">
                            <span class="timeline-text-left">May 2022</span>
                     </div>
                </div>
                <div class="row">
                <div class="col-sm-6 news-item">
                            <span class="timeline-text-right">June 2022</span>
                     </div>
                    <div class="col-sm-6 news-item right item-4">
                        <div class="news-content">
                            
                            <div class="news-media gallery">
                                <a class="colorbox cboxElement" href="#">
                                </a>
                                <a class="colorbox cboxElement" href="#"></a>
                            </div>
                            <ul>
                                <li><span style="font-weight: 400;">Market Place launch</span></li>
                                <li><span style="font-weight: 400;">Chain game emerge</span></li>
                            </ul>
                            <br/>
                        </div>
                    </div>
                </div>

                
                <div class="row">
                    <div class="col-sm-6 news-item left item-5">
                        <div class="news-content">
                            
                            <div class="news-media video">
                                <a class="colorbox-video cboxElement" href="#">
                                </a>
                            </div>
                            <ul>
                                <li><span style="font-weight: 400;">Arena NFT put on sale</span></li>
                            </ul>
                            <br/><br/>
                        </div>
                    </div>
                    <div class="col-sm-6 news-item">
                            <span class="timeline-text-left">Jul 2022</span>
                     </div>

                </div>
            </div>
        </div>
    </section>
    
     <section id="news" class="white-bg padding-top-bottom mobile-timeline">
        <div class="container bootstrap snippets bootdey">
        <h1 class="texttitle py-4 text-center" style="color:#fff;margin: 40px 0;" data-entrance="from-top">Roadmap</h1>
            <div class="timeline" data-entrance="from-bottom">
               
                <div class="row">
                    <div class="col-sm-12 news-item right item-1">
                        <span class="timeline-text-left">Mar 2022</span>
                        <div class="news-content">
                            
                            <div class="news-media">
                               
                            </div>
                            
                            <ul>
                                <li>NFT design</li>
                                <li><span style="font-weight: 400;">Officia2l website emerge</span></li>
                                <li><span style="font-weight: 400;">Seed round private placement</span></li>
                            </ul>
                        </div>
                    </div>
                   
                    </div>
                    <div class="row">
                    
                    <div class="col-sm-12 news-item right item-2">
                        <span class="timeline-text-right">Apr 2022</span>
                        <div class="news-content">
                            
                            <div class="news-media gallery">
                                <a class="colorbox cboxElement" href="#">
                                </a>
                                <a class="colorbox cboxElement" href="#"></a>
                            </div>
                            <ul>
                                <li><span style="font-weight: 400;">Publish horse NFT design</span></li>
                                <li><span style="font-weight: 400;">Private sale</span></li>
                                <li><span style="font-weight: 400;">Public sale</span></li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-sm-12 news-item right item-3">
                        <span class="timeline-text-left">May 2022</span>
                        <div class="news-content">
                            <div class="news-media video">
                                <a class="colorbox-video cboxElement" href="#">
                                </a>
                            </div>
                            <ul>
                                <li><p><span style="font-weight: 400;">Governance token launch</span></p></li>
                                <li><p><span style="font-weight: 400;">NFT blind box and training centre NFT put on sale</span></p></li>
                            </ul>
                        </div>
                    </div>
                   
                </div>
                <div class="row">
                
                    <div class="col-sm-12 news-item right item-4">
                        <span class="timeline-text-right">June 2022</span>
                        <div class="news-content">
                            
                            <div class="news-media gallery">
                                <a class="colorbox cboxElement" href="#">
                                </a>
                                <a class="colorbox cboxElement" href="#"></a>
                            </div>
                            <ul>
                                <li><span style="font-weight: 400;">Market Place launch</span></li>
                                <li><span style="font-weight: 400;">Chain game emerge</span></li>
                            </ul>
                            <br/>
                        </div>
                    </div>
                </div>

                
                <div class="row">
                    <div class="col-sm-12 news-item right item-5">
                        <span class="timeline-text-left">Jul 2022</span>
                        <div class="news-content">
                            
                            <div class="news-media video">
                                <a class="colorbox-video cboxElement" href="#">
                                </a>
                            </div>
                            <ul>
                                <li><span style="font-weight: 400;">Arena NFT put on sale</span></li>
                            </ul>
                            <br/><br/>
                        </div>
                    </div>
                    

                </div>
            </div>
        </div>
    </section>
</div>