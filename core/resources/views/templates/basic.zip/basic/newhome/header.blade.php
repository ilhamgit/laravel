<nav class="navbar navbar-expand-md shadow-sm">
    <div class="row w-100 py-3">
        <div class="col-md-2 d-xs-none"></div>
        <div class="col-md-8">
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav mx-auto">
                    <li class="nav-item my-4 px-2"><a href="#whitepaper" class="nav-link">Whitepaper</a></li>
                    <li class="nav-item my-4 px-2"><a href="#video" class="nav-link">Video</a></li>
                    <li class="nav-item my-4 px-2"><a href="#gameplay" class="nav-link">GamePlay</a></li>
                    <li class="nav-item my-4 px-2"><a href="#tokenomic" class="nav-link">Tokenomics</a></li>
                    <li class="nav-item px-2"><a href="/" class="nav-link"><img src="{{ asset('assets/newhome/storage/img/logo.png') }}" width="90px"></a></li>
                    <li class="nav-item my-4 px-2"><a href="#purchase" class="nav-link">Purchase Coin</a></li>
                    <li class="nav-item my-4 px-2"><a href="#nft" class="nav-link">NFT</a></li>
                    <li class="nav-item my-4 px-2"><a href="#roadmap" class="nav-link">Roadmap</a></li>
                    <li class="nav-item my-4 px-2"><a href="#" class="nav-link">EN</a></li>
                </ul>
            </div>
        </div>
        <div class="col-md-2 d-xs-none d-flex align-items-center justify-content-center ">
            @auth
                    <div class="d-none d-md-block">
                        <a href="{{route('user.home')}}" class="btn btn-default btn-md">@lang('Dashboard')</a>
                    </div>
                @else
                    <div class="right-area d-none d-md-block">
                        <!--<a href="{{route('user.register')}}" class="cmn--btn btn--sm">@lang('Register Now')</a>-->
                        <!--<a href="{{route('user.login')}}">-->
                        <!--    <i class="las la-user"></i>-->
                        <!--    <span>@lang('Login Now')</span>-->
                        <!--</a>-->
                         <a href="#" class="btn btn-default btn-md" onclick="web3Login();">@lang('Connect To Wallet')</a> 
                    </div>
                @endguest
        </div>
    </div>
</nav>
<section class="main-banner w-100 p-none">
    <video autoplay muted loop id="main-banner-video">
      <source src="{{ asset('assets/videos/horse.mp4') }}" type="video/mp4">
    </video>
</section>