<div id="purchase">
<div class="py-5" id="box3">
    <div class="container">
        <div class="row">
            <div class="col-md-6 d-flex align-middle align-center p-3" data-entrance="from-top">
                <img src="{{ asset('assets/newhome/storage/img/coin.png') }}" class="w-50 m-auto">
            </div>
            <div class="col-md-6 align-middle align-center p-3" data-entrance="from-right">
                <h2 class="d-block texttitle">Purchased Coin</h2>
                <div class="table-responsive">
                    <table class="table table-borderless mb-2 text-white">
                        <tr>
                            <td class="w-50">Total Purchased:</td><td>0.00MHC</td>
                        </tr>
                        <tr>
                            <td class="w-50">Total Released:</td><td>0.00MHC</td>
                        </tr>
                        <tr>
                            <td class="w-50">Total Locked:</td><td>0.00MHC</td>
                        </tr>
                    </table>
                </div>
                <div class="table-responsive">
                    <table class="table table-borderless mb-2 text-white">
                        <tr>
                            <td class="w-50">Powered by:</td><td></td>
                        </tr>
                        <tr>
                            <td class="w-50">Private Sale:</td><td></td>
                        </tr>
                        <tr>
                            <td class="w-50">Public Sale:</td><td></td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
</div>