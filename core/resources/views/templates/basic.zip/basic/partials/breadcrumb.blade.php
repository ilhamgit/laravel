<section class="hero-section">

        <div class="hero-content">
            <h4 class="title mb-0">{{__($pageTitle)}}</h4>
        </div>

</section>
