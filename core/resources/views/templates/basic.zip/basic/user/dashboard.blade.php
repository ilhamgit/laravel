@extends($activeTemplate.'layouts.userfrontend')
@section('content')
    @include($activeTemplate.'partials.breadcrumb')

    {{session()->get('jwt')}}

    <section class="dashboard-section bg--section text-uppercase">
            <!-- Dashboard -->
            <div class="pb-50">
                <div class="row justify-content-center g-4">

                    <div class="col-md-4">
                            <div class="dashboard__item text-right bg-blue">
                                <div class="dashboard__content w-100">
                                    <!--<h4 class="dashboard__title">{{__($general->cur_sym)}} {{showAmount($user->balance)}}</h4>-->
                                    <h4 class="dashboard__title">{{$widget['Summary']['bets']['unclaimedRewards']}}</h4>
                                    <span class="text-white">@lang('Pending Rewards')</span>
                                    <div class="row mt-2">
                                        <div class="col-md-12">
                                            <a href="{{  url('user/game-rewards') }}"><button type="button" class="btn text-uppercase btn-light">View All</button></a>
                                            

                                            <button type="button" class="btn text-uppercase @php if($widget['Summary']['bets']['unclaimedRewards']>0){echo 'btn-light claim';}else{echo 'btn-secondary disabled';} @endphp">Claim</button>
                                        </div>
                                    </div>

                                </div>
                            </div>
                    </div>

                    <div class="col-md-4">
                            <div class="dashboard__item text-right bg-blue">
                                <div class="dashboard__content w-100">
                                    <!--<h4 class="dashboard__title">{{__($general->cur_sym)}} {{showAmount($user->balance)}}</h4>-->
                                    <h4 class="dashboard__title">{{$widget['Summary']['pendingDeposit']}}</h4>
                                    <span class="text-white">@lang('Pending Deposit')</span>
                                    <div class="row mt-2">
                                        <div class="col-md-12">
                                            <a href="{{  url('user/game-deposit') }}"><button type="button" class="btn text-uppercase btn-light">View All</button></a>

                                            <button type="button" class="btn text-uppercase btn-light">Deposit</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                    </div>

                    <div class="col-md-4">
                            <div class="dashboard__item text-right bg-purple">
                                <div class="dashboard__content w-100">
                                    <!--<h4 class="dashboard__title">{{__($general->cur_sym)}} {{showAmount($user->balance)}}</h4>-->
                                    <h4 class="dashboard__title">{{$widget['Summary']['pendingWithdrawal']}}</h4>
                                    <span class="text-white">@lang('Pending Withdrawal')</span>
                                    <div class="row mt-2">
                                        <div class="col-md-12">
                                            <a href="{{  url('user/game-withdrawal') }}"><button type="button" class="btn text-uppercase btn-light">View All</button></a>
                                            <button type="button" class="btn text-uppercase btn-light">Withdraw</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                    </div>
                </div>
            </div>
    </section>

    <section class="dashboard-section bg--section text-uppercase">
        <div class="pb-50">
            <div class="row justify-content-center g-4">
                <div class="col-md-12">
                    <a href="#" class="w-100 match-join"><img src="{{url('assets/images/dashboard/01.OsakaBanner.png')}}" class="w-100"></a>
                </div>

                <div class="col-md-4">
                    <a href="{{  url('user/place-bet') }}" class="w-100"><img src="{{url('assets/images/dashboard/02.PlayNow.png')}}" class="w-100"></a>
                </div>
                <div class="col-md-4">
                    <a href="{{  url('user/horses') }}" class="w-100"><img src="{{url('assets/images/dashboard/03.ViewHorseBanner.png')}}" class="w-100"></a>
                </div>
                <div class="col-md-4">
                    <a href="{{  url('user/horse-train') }}" class="w-100"><img src="{{url('assets/images/dashboard/04.TrainHorseBanner.png')}}" class="w-100"></a>
                </div>

                <div class="col-md-4">
                    <a href="{{  url('user/mystery-box') }}" class="w-100"><img src="{{url('assets/images/dashboard/05.MystertBoxBanner.png')}}" class="w-100"></a>
                </div>
                <div class="col-md-4">
                    <a href="{{  url('user/items') }}" class="w-100"><img src="{{url('assets/images/dashboard/06.ViewItemBanner.png')}}" class="w-100"></a>
                </div>
                <div class="col-md-4">
                    <a href="{{  url('user/canteen') }}" class="w-100"><img src="{{url('assets/images/dashboard/07.EquipItemBanner.png')}}" class="w-100"></a>
                </div>
            </div>
        </div>
    </section>

    <!-- <pre class> -->

    @php

    //print_r($widget['Summary']);

    @endphp

    <!-- </pre> -->

    <section class="dashboard-section bg-meta-light-dark text-uppercase">
        <div class="container">
            <div class="pb-50">
                <div class="row pt-4 px-2">
                    <div class="col-md-6 analysis">
                        <h4 class="title mb-3 mx-3">@lang('Analysis')</h4>
                        <div class="row m-3 py-4 px-3 bg-light">
                            <div class="col-md-3 text-center">
                                <h5 class="a-results">
                                <i class="las la-trophy"></i>
                                @php

                                echo $widget['Summary']['bets']['winningRate']*100;

                                @endphp
                                </h5>
                                <p class="my-2 a-title">Win %</p>
                            </div>
                            <div class="col-md-3 text-center">
                                <h5 class="a-results"><i class="lab la-ethereum"></i>{{$widget['Summary']['bets']['rewards']}}</h5>
                                <p class="my-2 a-title">Winnings</p>
                            </div>
                            <div class="col-md-3 text-center">
                                <h5 class="a-results"><i class="lab la-ethereum"></i>{{$widget['Summary']['bets']['profits']}}</h5>
                                <p class="my-2 a-title">Profits</p>
                            </div>
                            <div class="col-md-3 text-center">
                                <h5 class="a-results"><i class="lab la-font-awesome-flag"></i>{{$widget['Summary']['bets']['race']}}</h5>
                                <p class="my-2 a-title"># of Races</p>
                            </div>
                        </div>
                        <div class="row m-3 p-3 bg-light">
                            <div class="col-md-12 text-center">
                                <canvas id="finalPos" style="width:100%;max-width:700px"></canvas>
                            </div>
                        </div>
                        
                        <div class="row m-3 p-3 bg-light">
                            <div class="col-md-12 text-center">
                                <canvas id="distance" style="width:100%;max-width:700px"></canvas>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        
                        <h4 class="title mb-3 mx-1">@lang('Top Horses')</h4>

                        @forelse ($widget['Summary']['horses'] as $horse)
                            <div class="row m-1 px-3 bg-light horses-details">
                                <div class="col-md-12 p-2">
                                    
                                    <div class="row py-2 bg-grey">
                                        <div class="col-md-3 p-none">
                                            <img src="https://d1k0k5uveaqxkp.cloudfront.net/fit-in/300x300/{{$horse['fileName']}}" width="100%">
                                        </div>
                                        <div class="col-md-9 d-flex">
                                            <h4 class="my-auto">{{$horse['horseName']}}</h4>
                                        </div>
                                    </div>

                                    <div class="row py-2 bg-grey">
                                        <div class="col-md-3 py-3 text-left">
                                            <p class="text-white text-bold">Total Race:</p>
                                        </div>
                                        <div class="col-md-3 py-3 text-left">
                                            <p class="text-white">{{$horse['raceCount']}} Races</p>
                                        </div>
                                        <div class="col-md-3 py-3 text-left">
                                            <p class="text-white text-bold">Lifespan:</p>
                                        </div>
                                        <div class="col-md-3 py-3 text-left">
                                            <p class="text-white">{{$horse['age']}} Years</p>
                                        </div>
                                        <div class="col-md-3 py-3 text-left">
                                            <p class="text-white text-bold">Horse Type:</p>
                                        </div>
                                        <div class="col-md-3 py-3 text-left">
                                            @if ($horse['isSuperHorse']!='')
                                                <p class="text-white">Super</p>
                                            @else
                                                <p class="text-white">Normal</p>
                                            @endif
                                        </div>
                                    </div>

                                    <div class="row mt-4 bg-light">
                                        <div class="col-md-6 text-center">
                                            <h5 class="a-results">
                                            <i class="las la-trophy"></i>
                                            @php

                                            echo $horse['winningRate']*100;

                                            @endphp

                                            </h5>
                                            <p class="my-2 a-title d-inline px-3">Win %</p>
                                        </div>
                                        <div class="col-md-6 text-center">
                                            <h5 class="a-results"><i class="lab la-font-awesome-flag"></i>{{$horse['bestRanking']}}</h5>
                                            <p class="my-2 a-title d-inline px-3"># of Races</p>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        @empty
                            <p class="text-white py-3">N/A</p>
                        @endforelse

                    </div>
                </div>
            </div>
        </div>
    </section>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.4/Chart.js"></script>
    <script>

        console.log("{{session()->get('jwt')}}");
        (function($){
            "use strict";

            $('.copytext').on('click',function(){
                var copyText = document.getElementById("referralURL");
                copyText.select();
                copyText.setSelectionRange(0, 99999);
                document.execCommand("copy");
                iziToast.success({message: "Copied: " + copyText.value, position: "topRight"});
            });

            @php

            echo 'var FPxValues = [';

            foreach($widget['Summary']['rankings'] as $ranking){
                echo '"'.$ranking['ranking'].'",';
            }

            echo '];
            var FPyValues = [';
            foreach($widget['Summary']['rankings'] as $ranking){
                echo '"'.$ranking['quantity'].'",';
            }
            echo '];';

            @endphp

            new Chart("finalPos", {
              type: "bar",
              data: {
                labels: FPxValues,
                datasets: [{
                  backgroundColor: '#75A89F',
                  data: FPyValues
                }]
              },
              options: {
                legend: {display: false},
                title: {
                  display: true,
                  text: "FINAL POSITIONS"
                }
              }
            });


            @php

            echo 'var DxValues = [';

            foreach($widget['Summary']['distances'] as $distance){
                echo '"'.$distance['distance'].'",';
            }

            echo '];
            var DyValues = [';
            foreach($widget['Summary']['distances'] as $distance){

                $percent=$distance['winningRate']*100;

                echo '"'.$percent.'",';
            }
            echo '];';

            @endphp

            new Chart("distance", {
              type: "bar",
              data: {
                labels: DxValues,
                datasets: [{
                  backgroundColor: '#75A89F',
                  data: DyValues
                }]
              },
              options: {
                legend: {display: false},
                title: {
                  display: true,
                  text: "WINNING % BY DISTANCE"
                }
              }
            });

            $("button.claim").on("click", function(event){

               var user='{{$user->username}}';

                var plink = "{{url('user/claim-reward')}}";

                $('<form action="'+plink+'" method="post">@csrf<input type="hidden" name="user" value="'+user+'"></form>').appendTo('body').submit();

            });

            $('.match-join').on('click',function(e){

                e.preventDefault();

                var plink = "{{url('user/verify-match')}}";

                $('<form action="'+plink+'" method="post">@csrf<input type="hidden" name="join" value="1"></form>').appendTo('body').submit();

              });

        })(jQuery);
    </script>

@endsection


