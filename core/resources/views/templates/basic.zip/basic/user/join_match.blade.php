@extends($activeTemplate.'layouts.userfrontend')
@section('content')
    @include($activeTemplate.'partials.breadcrumb')

    <section class="bg--section">
        <div class="text-uppercase">
          <div class="match-banner mb-5 mt-2"><a href="#" class="w-100 match-join"><img src="{{url('assets/images/dashboard/01.OsakaBanner.png')}}" class="w-100"></a></div>
            <div class="text-white mb-3">
              <p>My Listed Match <i class="las la-info round-border" data-toggle="tooltip" title="MY MATCHES (JOINED BY MY HORSES) IN DAILY SCHEDULE"></i></p>
            </div>

            <div class="table-responsive">
                      <table class="table table-dark text-center w-md-100">
                        <thead>
                            <tr>
                              <th scope="col">Location</th>
                              <th scope="col">Distance</th>
                              <th scope="col">Type</th>
                              <th scope="col">Date Time <i class="las la-info round-border" data-toggle="tooltip" title="MATCH STARTED FROM THE DATETIME"></i></th>
                              <th scope="col">Countdown <i class="las la-info round-border" data-toggle="tooltip" title="COUNTDOWN TO MATCH START"></i></th>
                              <th scope="col">Result</th>
                              <th scope="col">Replay</th>
                            </tr>
                          </thead>
                          <tbody>
                            @forelse ($gdata['daily_match'] as $no => $d_data)
    
                                <tr data-mid="{{$d_data->matchId}}">
                                    <td>{{$d_data->stadiumName}}</th>
                                    <td>{{$d_data->stadiumDistance}}M</td>
                                    <td>{{$d_data->routeType}}</td>
                                    @php

                                      $tstamp=strtotime($d_data->betStartDate);

                                      $offset=9*60*60;

                                      // get the local timezone
                                      $loc = (new DateTime)->getTimezone();

                                      $tstamp=strtotime($d_data->betStartDate);

                                      $slt = new DateTime($d_data->betStartDate, new DateTimeZone('UTC'));

                                      // change the timezone of the object without changing its time
                                      $slt->setTimezone($loc);


                                      $startlive=strtotime($slt->format('Y-m-d H:i:s T'));



                                      $elt = new DateTime($d_data->betEndDate, new DateTimeZone('UTC'));

                                      // change the timezone of the object without changing its time
                                      $elt->setTimezone($loc);


                                      $endlive=strtotime($elt->format('Y-m-d H:i:s T'));

                                      echo '<td data-date="'.date('d F Y h:i:s',$tstamp).' GMT+09:00">';

                                      echo date('l, d M Y h:i',$tstamp).' (GMT +9)';

                                      echo '</td>';

                                      echo '<td class="countdown" data-datetime="'.date('d M Y h:i:s a',$startlive).'" data-endlive="'.date('d M Y h:i:s a',$endlive).'"><div id="days" class="d-inline-block"></div> <div id="hours" class="d-inline-block"></div> <div id="minutes" class="d-inline-block"></div> <div id="seconds" class="d-inline-block">';

                                      echo '</td>';

                                      @endphp
                                    <td>
                                      <button class="btn btn-result px-2 py-3 text-white text-uppercase btn-golden disabled" resno="{{$no}}">View</button>
                                    </td>
                                    <td>
                                      <button class="btn btn-replay px-2 py-3 text-white text-uppercase btn-golden disabled" repno="{{$no}}">Watch</button>
                                    </td>
                                </tr>

                            @empty
                                <tr>
                                    <td colspan="7" class="text-center">No Match Available.</td>
                                </tr>

                            @endforelse
                          </tbody>
                      </table>
                      <div class="modal modal-result">

                                        <!-- Modal content -->
                                        <div class="modal-content text-center">
                                          <span class="close mb-2">&times;</span>
                                          
                                          <div class="list-data"></div>

                                        </div>

                                      </div>
                    </div>

                    <div class="modal modal-replay">

                                      <!-- Modal content -->
                                      <div class="modal-content text-center">
                                        <span class="close mb-2">&times;</span>

                                        <div class="embed-responsive embed-responsive-1by1 w-100 replay-iframe">
                                        </div>

                                      </div>

                                    </div>
                    </div>
        </div>
    </section>

    <script>
      $(function () {
        $('[data-toggle="tooltip"]').tooltip();

        var modal = '';

        var span = document.getElementsByClassName("close")[0];

        $('.btn-result').on('click',function(){

          $nop = $(this).attr('resno');

          var modal = $('#result-'+$nop).attr('id');

          $('#result-'+$nop).show();


        });


        $('.btn-replay').on('click',function(){

          $nop = $(this).attr('repno');

          var modal = $('#replay-'+$nop).attr('id');

          $('#replay-'+$nop).show();


        });

        $('.close').on('click',function(){
          $(this).closest('.modal').hide();
        });

        $('.match-join').on('click',function(e){

                e.preventDefault();

                var plink = "{{url('user/verify-match')}}";

                $('<form action="'+plink+'" method="post">@csrf<input type="hidden" name="join" value="1"></form>').appendTo('body').submit();

              });



      });

      function makeTimer(e) {

        $('.countdown').each(function(){

          var gdate=$(this).data('datetime');

          var eldate=$(this).attr('data-endlive');

          var endTime = new Date(gdate);      
          endTime = (Date.parse(endTime) / 1000);

          var endLive = new Date(eldate);      
          endLive = (Date.parse(endLive) / 1000);

          var now = new Date();
          now = (Date.parse(now) / 1000);

          var timeLeft = endTime - now;

          var willend = endLive - now;

          var days = Math.floor(timeLeft / 86400); 
          var hours = Math.floor((timeLeft - (days * 86400)) / 3600);
          var minutes = Math.floor((timeLeft - (days * 86400) - (hours * 3600 )) / 60);
          var seconds = Math.floor((timeLeft - (days * 86400) - (hours * 3600) - (minutes * 60)));

          if(willend<=0) {

            $(this).html('<strong class="text-white">Passed</strong>');

            $(this).closest('tr').find('button.disabled').removeClass('disabled');

          }else if(timeLeft<=0) {

            $(this).html('<strong class="text-white">LIVE</strong>');

            $(this).attr('data-endlivesec',willend);

          }else{
            if (hours < "10") { hours = "0" + hours; }
            if (minutes < "10") { minutes = "0" + minutes; }
            if (seconds < "10") { seconds = "0" + seconds; }

            $(this).find("#days").html(days + "<span>D</span>");
            $(this).find("#hours").html(hours + "<span>H</span>");
            $(this).find("#minutes").html(minutes + "<span>M</span>");
            $(this).find("#seconds").html(seconds + "<span>S</span>");
            $(this).attr('data-timeleft',timeLeft);

            $(this).attr('data-endlivesec',willend);
          }
      

        });

      //    var endTime = new Date("29 April 2018 9:56:00 GMT+01:00");  
             

      }

      setInterval(function() { makeTimer(); }, 1000);
    </script>

@endsection

