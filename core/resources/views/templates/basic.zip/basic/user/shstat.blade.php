@extends($activeTemplate.'layouts.userfrontend')
@section('content')
    @include($activeTemplate.'partials.breadcrumb')

    @php

    $h_details=$gdata['horses_new'];


    if(isset($h_details->horseId)){

    @endphp

        <section class="bg--section">
        <div class="text-uppercase">
            
            <div class="row justify-content-between">
                <div class="col-lg-6 d-none d-lg-block">
                    <div class="row">
                        <div class="col-6 py-3">
                            <h4 class="text-white text-left">{{$h_details->horseName}}</h4>
                        </div>
                        <div class="col-6 text-right">
                            <a href="{{  url('user/super-breed') }}" class="btn btn-golden px-3 py-2">Back</a>
                        </div>
                    </div>
                    <div class="about--thumb @php if($h_details->isDestroyed===true){ echo'destroyed';} @endphp">
                        @php
                        if($h_details->isSuperHorse=='true'){

                            $sh_badge=getImage(imagePath()['logoIcon']['path'] .'/SuperBreed.png');

                            echo '<img class="sh-badge" src="'.$sh_badge.'" width="80px">';
                        }
                        @endphp
                        <img src="https://d1k0k5uveaqxkp.cloudfront.net/fit-in/500x500/{{$h_details->fileName}}" width="100%">
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="horse-stat-content pb-3">
                        <div class="row mb-1">
                            <div class="col-12 py-1">
                                <h4 class="text-white">About</h4>
                            </div>
                        </div>
                        <div class="row mb-5 bg-grey border-between">
                            <div class="col-md-3 col-6 p-2">
                                <span class="text-bold">Total Race:</span>
                            </div>
                            <div class="col-md-3 col-6 p-2 bdr-right">
                                <span>{{$h_details->raceCount}} races</span>
                            </div>
                            <div class="col-md-3 col-6 p-2">
                                <span class="text-bold">Lifespan:</span>
                            </div>
                            <div class="col-md-3 col-6 p-2">
                                <span>{{$h_details->age}} Years</span>
                            </div>
                            <div class="col-md-3 col-6 p-2">
                                <span class="text-bold">Horse Type:</span>
                            </div>
                            <div class="col-md-3 col-6 p-2 bdr-right">
                                @php

                                    if($h_details->isSuperHorse=='true'){
                                        echo '<span>Super</span>';
                                    }else{
                                        echo '<span>Normal</span>';
                                    }

                                @endphp
                            </div>
                            <div class="col-md-3 col-6 p-2">
                                <span class="text-bold">Convert:</span>
                            </div>
                            <div class="col-md-3 col-6 p-2">
                                @php

                                    if($h_details->isEligibleSuperHorse=='true'){
                                        echo '<span>Yes</span>';
                                    }else{
                                        echo '<span>No</span>';
                                    }

                                @endphp
                            </div>
                            <div class="text-white col-md-12 px-2"><hr class="my-2" /></div>
                            <div class="col-md-3 col-6 p-2">
                                <span class="text-bold">Owner:</span>
                            </div>
                            <div class="col-md-9 col-6 p-2">
                                {{$h_details->username}}
                            </div>
                        </div>

                        <div class="row mb-1">
                            <div class="col-12">
                                <h4 class="text-white">Stats</h4>
                            </div>
                        </div>

                        <div class="row mb-3 bg-grey border-between">
                            <div class="col-md-4 p-3 bdr-right">
                                <p class="stat-title text-center">Speed</p>
                                <div class="row">
                                    <div class="col-md-4 text-center">
                                        <img src="{{ getImage(imagePath()['logoIcon']['path'] .'/speed_icon.png') }}" width="60px" height="60px">
                                    </div>
                                    <div class="col-md-8 text-center py-2">
                                        <h3 class="text-white text-center">{{$h_details->speed}}</h3>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4 p-3 bdr-right">
                                <p class="stat-title text-center">Endurance</p>
                                <div class="row">
                                    <div class="col-md-4 text-center">
                                        <img src="{{ getImage(imagePath()['logoIcon']['path'] .'/endurance_icon.png') }}" width="60px" height="60px">
                                    </div>
                                    <div class="col-md-8 text-center py-2">
                                        <h3 class="text-white text-center">{{$h_details->endurance}}</h3>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4 p-3">
                                <p class="stat-title text-center">Stamina</p>
                                <div class="row">
                                    <div class="col-md-4 text-center">
                                        <img src="{{ getImage(imagePath()['logoIcon']['path'] .'/stamina.png') }}" width="60px" height="60px">
                                    </div>
                                    <div class="col-md-8 text-center py-2">
                                        <h3 class="text-white text-center">{{$h_details->stamina}}</h3>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row mb-3 bg-grey border-between">
                            <div class="col-md-4 p-3 bdr-right">
                                <p class="stat-title text-center">Force</p>
                                <div class="row">
                                    <div class="col-md-4 text-center">
                                        <img src="{{ getImage(imagePath()['logoIcon']['path'] .'/power.png') }}" width="60px" height="60px">
                                    </div>
                                    <div class="col-md-8 text-center py-2">
                                        <h3 class="text-white text-center">{{$h_details->force}}</h3>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4 p-3 bdr-right">
                                <p class="stat-title text-center">Temper</p>
                                <div class="row">
                                    <div class="col-md-4 text-center">
                                        <img src="{{ getImage(imagePath()['logoIcon']['path'] .'/temper.png') }}" width="60px" height="60px">
                                    </div>
                                    <div class="col-md-8 text-center py-2">
                                        <h3 class="text-white text-center">{{$h_details->temper}}</h3>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4 p-3">
                                <button type="button" class="btn btn-golden btn-breed mx-auto d-block w-100 h-100">Super Breed</button>
                            </div>
                        </div>

                    </div>
                </div>            
            </div>

        </div>
    </section>

    <script>
        $(document).ready(function($){

                $(".btn-breed").on("click", function(event){

                    var user='{{$user->username}}';
                    var horse='{{$h_details->horseId}}';

                    @php

                        if($h_details->isSuperHorse=='true'){
                            echo 'var type="Super";';
                        }else{
                            echo 'var type="Super";';
                        }

                    @endphp

                    $('<form method="post">@csrf<input type="hidden" name="hid" value="'+horse+'"><input type="hidden" name="type" value="'+type+'"></form>').appendTo('body').submit();
                });
            });
    </script>

    @php


    }else{


        $message = $h_details->messages;

        $notify[] = ['error', $message[0]];
        echo back()->withNotify($notify);

    }



    //echo '<pre class="text-white">';

    //print_r($gdata['horses_new']);

    //echo '</pre>';

    @endphp



@endsection

