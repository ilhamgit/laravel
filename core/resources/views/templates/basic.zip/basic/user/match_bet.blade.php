@extends($activeTemplate.'layouts.userfrontend')
@section('content')
	<style>
		.horse {
			width: 47%;
			height: 100%; 
			border-radius: 0 0 0 15%;
		}

			.horse-bet-box {
				width: 10%;
				height: 8.2%; 
				cursor: pointer;
				color: white;
			}

				.horse-font {
					font-size: 0.8em; 
					left: 10%; 
					font-weight: bold; 
					color: #000!important;
					text-shadow: -1px -1px 0 #fff, 1px -1px 0 #fff, -1px 1px 0 #fff, 1px 1px 0 #fff;
				}

				.horse-image {
					width: 320%; 
					height: 220%;
					top: -20%;
				}

				.horse-bet-amount {
					font-size: 0.6em;
					left: 68%;
					bottom: 0%;
				}

				.horse-column-1 {
					left: 11.5%;
				}

				.horse-column-2 {
					left: 22.8%; 
				}

				.horse-column-3 {
					left: 33%;
				}

				.horse-column-4 {
					left: 44%; 
				}

				.horse-column-5 {
					left: 54.8%;
				}

				.horse-column-6 {
					left: 65.7%; 
				}

				.horse-column-7 {
					left: 76.6%;
				}

				.horse-column-8 {
					left: 87.3%; 
				}

		.bet-box {
			width: 10%;
			height: 8.2%; 
			cursor: pointer;
			color: white;
		}

			.bet-odds {
				font-size: 0.6em;
				left: 60%;
				top: 20%;
				font-weight: bold; 
			}

			.bet-amount {
				font-size: 0.6em;
				left: 50%;
				bottom: -5%;
			}

			.bet-box.active, .horse-bet-box.active, .bs-bet-box.active{
				color: var(--quaternary)!important;
				font-weight: bolder;
			}

		.column-1 {
			left: 11.5%;
		}

		.column-2 {
			left: 22.8%; 
		}

		.column-3 {
			left: 33.7%;
		}

		.column-4 {
			left: 44.4%; 
		}

		.column-5 {
			left: 55.2%;
		}

		.column-6 {
			left: 65.9%; 
		}

		.column-7 {
			left: 76.6%;
		}

		.column-8 {
			left: 87.3%; 
		}

		.row-1 {
			top: 1.5%; 
		}

		.row-2 {
			top: 10.8%; 
		}

		.row-3 {
			top: 20.4%;
		}

		.row-4 {
			top: 29.7%;
		}

		.row-5 {
			top: 39.3%;
		}

		.row-6 {
			top: 48.6%;
		}

		.row-7 {
			top: 58.2%; 
		}

		.row-8 {
			top: 67.6%; 
		}

		/* Big / Small */
		.bs-row-1 {
			top: 27.3%;
			left: 17%;
			font-size: 0.8em;
		}

		.bs-row-2 {
			top: 45.5%;
			left: 17%;
			font-size: 0.8em;
		}

		.bs-row-3 {
			top: 63.7%;
			left: 17%;
			font-size: 0.8em;
		}

		.bs-row-4 {
			top: 82.2%;
			left: 17%;
			font-size: 0.8em;
		}

		.bs-bet-box {
			width: 20%;
			height: 16%;
			color: #333;
			cursor: pointer;
		}
			.bs-bet-box div {
				padding-top: 13%;
			}

			.bs-column-2 {
				left: 34%;
    			margin-top: -3%;
			}

			.bs-column-3 {
				left: 55%;
    			margin-top: -3%;
			}

			.bs-column-4 {
				left: 77%;
    			margin-top: -3%;
			}

		.token {
			cursor: pointer;
		}

			.token-5 {
				width: 5%;
				height: 45%;
				left: 30%;
				top: 20%;
			}

			.token-10 {
				width: 7%;
				height: 50%;
				left: 36%;
				top: 17%;
			}

			.token-50 {
				width: 8%;
				height: 56%;
				left: 44%;
				top: 14%;
			}

			.token-100 {
				width: 10%;
				height: 66%;
				left: 53%;
				top: 8%;
			}

			.token-500 {
				width: 12%;
				height: 78%;
				left: 64%;
				top: 1%;
			}
	</style>
	
	<section class="bg--section">
		<div >
			<div style="background-image: url('{{url('assets/images/bets/metahorse game bg.png')}}'); background-repeat: no-repeat; background-size: auto 100%; background-position: center;">
				<div class="row pt-3 px-3">
					<div class="col-12 col-sm-3">
						<div class="text-white mb-2 text-center">
							TIME LEFT: <span>23:59:59</span>
						</div>

						<img src="{{url('assets/images/bets/left-chart.png')}}" class="w-100"></a>
					</div>
					<div class="col-12 col-sm-9 position-relative">
						<img src="{{url('assets/images/bets/metachart.png')}}" class="w-100"></a>
						{{-- Horses --}}
						@foreach($gdata['current_match']->horses as $key => $horse)
						<div class="position-absolute overflow-hidden place-bet horse-bet-box row-1 horse-column-{{ $key+1 }}" data-bet="bet_{{ $key+1 }}">
							<div class="position-absolute overflow-hidden horse horse-{{ $key+1 }}">
								<img src="https://d1k0k5uveaqxkp.cloudfront.net/fit-in/100x100/{{ $horse->fileName }}" class="position-absolute horse-image"></a>
								<div class="text-white position-absolute bottom-0 horse-font">{{ $key+1 }}</div>
							</div>
							<div class="position-absolute bet-odds">x{{ $gdata['current_match']->singleOdds->{'odd_'.($key+1)} }}</div>
							<div class="position-absolute horse-bet-amount bet_{{ $key+1 }}" data-bet="{{ $key+1 }}">0</div>
						</div>
						@endforeach

						{{-- Betting Box --}}
						@for($i = 1; $i < 8; $i++)
							@for($j = $i; $j < 8; $j++)
							<div class="position-absolute overflow-hidden place-bet bet-box row-{{$i+1}} column-{{$j+1}}" data-bet="bet_{{ $i }}_{{ ($j+1) }}">
								<div class="position-absolute bet-odds">x{{ $gdata['current_match']->doubleOdds->{'odd_'.($i).'_'.($j+1)} }}</div>
								<div class="position-absolute bet-amount bet_{{ $i }}_{{ ($j+1) }}" data-bet="{{ $i }}_{{ ($j+1) }}">0</div>
							</div>
							@endfor
						@endfor

						<div class="col-4 col-sm-4 position-absolute bottom-0">
							<img src="{{url('assets/images/bets/chart.png')}}" class="w-100"></a>

							{{-- Big/Small --}}
							<div class="position-absolute bs-row-1">
								<div class="text-white position-absolute bs_odd">{{ $gdata['current_match']->evenOddBigSmallOdds->odd_Odd_1 }}</div>
							</div>

							<div class="position-absolute bs-row-2">
								<div class="text-white position-absolute bs_even">{{ $gdata['current_match']->evenOddBigSmallOdds->odd_Even_1 }}</div>
							</div>

							<div class="position-absolute bs-row-3">
								<div class="text-white position-absolute bs_big">{{ $gdata['current_match']->evenOddBigSmallOdds->odd_Big_1 }}</div>
							</div>

							<div class="position-absolute bs-row-4">
								<div class="text-white position-absolute bs_small">{{ $gdata['current_match']->evenOddBigSmallOdds->odd_Small_1 }}</div>
							</div>

							{{-- Big/Small Bet Box --}}
							@for($i = 1; $i < 4; $i++)
							<div class="position-absolute bs-row-1 bs-column-{{ $i+1 }} bs-bet-box" data-bet="bs_odd_{{ $i }}" data-odd="{{ $gdata['current_match']->evenOddBigSmallOdds->{'odd_Odd_'.$i} }}">
								<div class="text-center">0</div>
							</div>

							<div class="position-absolute bs-row-2 bs-column-{{ $i+1 }} bs-bet-box" data-bet="bs_even_{{ $i }}" data-odd="{{ $gdata['current_match']->evenOddBigSmallOdds->{'odd_Even_'.$i} }}">
								<div class="text-center">0</div>
							</div>

							<div class="position-absolute bs-row-3 bs-column-{{ $i+1 }} bs-bet-box" data-bet="bs_big_{{ $i }}" data-odd="{{ $gdata['current_match']->evenOddBigSmallOdds->{'odd_Big_'.$i} }}">
								<div class="text-center">0</div>
							</div>

							<div class="position-absolute bs-row-4 bs-column-{{ $i+1 }} bs-bet-box" data-bet="bs_small_{{ $i }}" data-odd="{{ $gdata['current_match']->evenOddBigSmallOdds->{'odd_Small_'.$i} }}">
								<div class="text-center">0</div>
							</div>
							@endfor
						</div>
					</div>
				</div>
				<div class="row pb-1">
					<div class="col-12 col-sm-10 position-relative">
						<img src="{{url('assets/images/bets/bar.png')}}" class="w-100"></a>

						{{-- Token --}}
						<div class="position-absolute token token-5" data-token="5">
						</div>

						<div class="position-absolute token token-10" data-token="10">
						</div>

						<div class="position-absolute token token-50" data-token="50">
						</div>

						<div class="position-absolute token token-100" data-token="100">
						</div>

						<div class="position-absolute token token-500" data-token="500">
						</div>
					</div>
				</div>
		</div>
	</section>

	<script>
		// Get the modal
		$(document).ready(function(){
			$('.place-bet, .bs-bet-box').click(function(){
				$('.place-bet, .bs-bet-box').removeClass('active');
				$(this).addClass('active');
			})
		});

		// function makeTimer(e) {
		// 	$('.countdown').each(function(){
		// 		var gdate=$(this).data('datetime');
		// 		var eldate=$(this).attr('data-endlive');

		// 		var endTime = new Date(gdate);      
		// 		endTime = (Date.parse(endTime) / 1000);

		// 		var endLive = new Date(eldate);      
		// 		endLive = (Date.parse(endLive) / 1000);

		// 		var now = new Date();
		// 		now = (Date.parse(now) / 1000);

		// 		var timeLeft = endTime - now;
		// 		var willend = endLive - now;
		// 		var days = Math.floor(timeLeft / 86400); 
		// 		var hours = Math.floor((timeLeft - (days * 86400)) / 3600);
		// 		var minutes = Math.floor((timeLeft - (days * 86400) - (hours * 3600 )) / 60);
		// 		var seconds = Math.floor((timeLeft - (days * 86400) - (hours * 3600) - (minutes * 60)));

		// 		if(willend <= 0) {
		// 			$(this).closest('tr').remove();

		// 		} else if(timeLeft <= 0) {
		// 			$(this).html('<strong class="text-white">LIVE</strong>');
		// 			$(this).closest('tr').find('button.disabled').removeClass('disabled');
		// 			$(this).attr('data-endlivesec',willend);
		// 		} else {
		// 			if (hours < "10") { hours = "0" + hours; }
		// 			if (minutes < "10") { minutes = "0" + minutes; }
		// 			if (seconds < "10") { seconds = "0" + seconds; }

		// 			$(this).find("#days").html(days + "<span>D</span>");
		// 			$(this).find("#hours").html(hours + "<span>H</span>");
		// 			$(this).find("#minutes").html(minutes + "<span>M</span>");
		// 			$(this).find("#seconds").html(seconds + "<span>S</span>");
		// 			$(this).attr('data-timeleft',timeLeft);
		// 			$(this).attr('data-endlivesec',willend);
		// 		}
		// 	}); 
		// }

		// setInterval(function() { makeTimer(); }, 1000);	
	</script>
@endsection

